<?php

// -----------------------------------------
// semplice child theme
// functions.php
// -----------------------------------------

// add your functions here